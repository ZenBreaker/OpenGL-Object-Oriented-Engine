#include "BSP.h"

void BSPNode::Draw()
{
}
